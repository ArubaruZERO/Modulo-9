import "./styles.css";

import * as dataBusiness from "./data-business";
import * as utils from "./utils";

dataBusiness.getCharacters().then(characters => {
  for (let character of characters) {
    const node = utils.createCharacterRow(character);
    document.getElementById("root").appendChild(node);
    node.onclick = function() {
      dataBusiness
        .getCharacterDetails(character.char_id)
        .then(characterDetails => {
          utils.showCharacter(characterDetails);
        });
    };
  }
});
